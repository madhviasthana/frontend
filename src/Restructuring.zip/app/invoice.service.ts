import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Invoice } from './invoice'

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {
  private baseURL ="http://localhost:8080/invoices";

  constructor(private httpClient : HttpClient) { }
  getList() : Observable<Invoice[]>
  {
    return this.httpClient.get<Invoice[]>(`${this.baseURL}`);
  }

}
