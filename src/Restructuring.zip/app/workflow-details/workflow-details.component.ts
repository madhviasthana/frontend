import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workflow-details',
  templateUrl: './workflow-details.component.html',
  styleUrls: ['./workflow-details.component.css']
})
export class WorkflowDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
