import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdf-details',
  templateUrl: './pdf-details.component.html',
  styleUrls: ['./pdf-details.component.css']
})
export class PdfDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
