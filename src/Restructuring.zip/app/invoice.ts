export class Invoice {
    invoiceNo!:number
    invoiceDate! : string;
    bookingId! : number;
    travelReqNo! : number;
    guestName! : string;
    roomType! : string;
    stayDuration! : string;
    tcsCost! : number;
    invoiceStatus! : string;



}

