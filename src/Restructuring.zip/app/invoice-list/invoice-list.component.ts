import { Component, OnInit } from '@angular/core';
import { Invoice } from '../invoice'
import { InvoiceService } from '../invoice.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-my-component',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.css']
})
export class InvoiceListComponent implements OnInit {

  invoices! : Invoice[];

  constructor(private router:Router,private invoiceService : InvoiceService) { }

  ngOnInit(): void {

    this.getDetails();


  }
  private getDetails()
  {
    this.invoiceService.getList().subscribe(data => {
    this.invoices = data;
    });
  }

}
