import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { InvoiceListComponent } from './invoice-list/invoice-list.component';
import { InvoiceDetailsComponent } from './invoice-details/invoice-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FilterComponent } from './filter/filter.component';
import { BasicDetailsComponent } from './basic-details/basic-details.component';
import { BookingDetailsComponent } from './booking-details/booking-details.component';
import { PdfDetailsComponent } from './pdf-details/pdf-details.component';
import { BillingDetailsComponent } from './billing-details/billing-details.component';
import { WorkflowDetailsComponent } from './workflow-details/workflow-details.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    InvoiceListComponent,
    InvoiceDetailsComponent,
    FilterComponent,
    BasicDetailsComponent,
    BookingDetailsComponent,
    PdfDetailsComponent,
    BillingDetailsComponent,
    WorkflowDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
